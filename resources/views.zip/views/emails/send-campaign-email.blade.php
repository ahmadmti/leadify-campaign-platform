@component('mail::message')

    {!! $mailContent !!}

@endcomponent