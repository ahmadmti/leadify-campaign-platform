<!-- Add Edit Modal -->
<div id="addEditModal" class="modal fade" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog @if($bootstrapModalRight) modal-right @endif modal-{{$bootstrapModalSize}}" role="document">
        <div class="modal-content">
            {{--Content to inserted by ajax data--}}
        </div>
    </div>
</div>