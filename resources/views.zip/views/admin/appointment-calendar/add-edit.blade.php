<style>
.time {
    width: 89%;
    padding: 10px;
    background-color: none;
    background: none;
    border-radius: 6px;
    margin-bottom: 9px;
    color: white;
    font-weight: 700;
    color: #46a3f7;
    font-size: 14px;
    border: 1px solid #49a5f7;
    /* border: none; */
    -webkit-appearance: button;
    display: flex;
    justify-content: center;
    cursor: pointer;
}

.time:focus {
    width: 89%;
    padding: 10px;
    background-color: none;
    background: none;
    border-radius: 6px;
    margin-bottom: 9px;
    color: white;
    font-weight: 700;
    color: #46a3f7;
    font-size: 14px;
    border: 1px solid #49a5f7;
    /* border: none; */
    -webkit-appearance: button;
    display: flex;
    justify-content: center;
    cursor: pointer;
}



.demo {
    width: 89%;
    padding: 10px;
    background-color: #007bff;
    margin-bottom: 9px;
    color: white;
    font-weight: 700;
    font-size: 14px;
    border: none;
    -webkit-appearance: button;
    display: flex;
    justify-content: center;
    cursor: pointer;
}

.loader {
    border: 16px solid #f3f3f3;
    border-top: 16px solid #3498db;
    border-radius: 50%;
    width: 120px;
    margin: 0;
    height: 120px;
    animation: spin 2s linear infinite;
    position: absolute;
    z-index: 1111;
    /* left: 0; */
    /* right: 0; */
    transform: );
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    margin: auto;
}

.input {
    color: #46a3f7;
}

.select {
    color: #43a2f7;
    font-weight: 700;
    background: aliceblue;
    border-radius: 50%;
}

@keyframes spin {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<div class="modal-header">
    <h5 class="modal-title">
        <i class="fa fa-{{ $icon }}"></i> @if(isset($appointment->id)) @lang('module_campaign.editAppointment') @else
        @lang('module_campaign.createAppointment') @endif
    </h5>
</div>
{!! Form::open(['url' => '','autocomplete'=>'off','id'=>'appointment-edit-form']) !!}
@if(isset($appointment->id)) <input type="hidden" name="_method" value="PUT"> @endif
<input type="hidden" name="lead_id" value="{{ $lead->id }}" />
<div class="modal-body">
    <div class="loader"></div>
    <div class="form-group row">
        <label class="col-sm-3 col-form-label">@lang('app.campaign')</label>
        <div class="col-sm-9">
            {{ $lead->campaign->name ?? ''}}
        </div>
    </div>



    <div class="form-group row">
        <label class="col-sm-3 col-form-label">@lang('module_campaign.appointmentTime')</label>
        <div class="col-sm-9">

            <div>

                <input type="text" id="appointment_time" name="appointment_time" data-toggle="dropdown"
                    class=" dropdown-toggle form-control" value="{{ $appointment->appointment_time ?? '' }}">
                <div class="dropdow">
                    <ul class="dropdown-menu" style="padding: 5px;width:100%;" role="menu" aria-labelledby="menu1">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="selectDay">
                                    <input type="text" disabled id="date" name="date" class="model input form-control"
                                        value="">
                                    <div class="calendar-container"></div>
                                </div>
                            </div>
                            <div class="col-md-4" style="max-height: 500px;overflow: auto;">
                                <div id="button">

                                </div>
                            </div>
                        </div>
                    </ul>
                </div>
            </div>

        </div>
    </div>


    <div class="form-group row">
        <label class="col-sm-3 col-form-label">@lang('module_campaign.salesMember')</label>
        <div class="col-sm-9">
            <select id="sales_member_id" name="sales_member_id" class="form-control select2 ">
                <option value="">@lang('module_campaign.selectSalesMember')</option>

            </select>
        </div>
    </div>



</div>
<div class="modal-footer bg-whitesmoke">
    <button id="saveFormButton" type="submit" class="btn btn-icon icon-left btn-success"
        onclick="addEditAppointment({{ $appointment->id ?? '' }});return false"><i class="fas fa-check"></i>
        @if(isset($appointment->id) && $appointment->id != '') @lang('app.update') @else @lang('app.save')
        @endif</button>
    @if(isset($appointment->id))
    <button id="cancelAppointmentButton" type="button" class="btn btn-icon icon-left btn-danger"
        onclick="deleteAppointment({{ $appointment->id ?? '' }});return false"><i class="fas fa-trash"></i>
        @lang('module_campaign.deleteAppointment')</button>
    @endif
    <button type="button" class="btn default"
        onclick="cancelAppointmentModal({{ isset($appointment->id) ? 1 : 0 }})">@lang('app.cancel')</button>
</div>

{{Form::close()}}

<script>
// calender
$(function() {
    $('.calendar-container').calendar();
});

$('.loader').hide();
$('ul.dropdown-menu').on('click', function(event) {

    event.stopPropagation();
});

function availableFunction() {
    var url = "{{ route('admin.check-availableDays') }}";
    $.easyAjax({
        type: 'GET',
        url: url,
        messagePosition: "toastr",
        success: function(response) {
            elementDay = response;
            var weekday = new Array(8);
            weekday["Sunday"] = 1;
            weekday["Monday"] = 2;
            weekday["Tuesday"] = 3;
            weekday["Wednesday"] = 4;
            weekday["Thursday"] = 5;
            weekday["Friday"] = 6;
            weekday["Saturday"] = 7;
          

            $('[data-week-no] .day').attr("disabled", "disabled");
            for (var i = 1; i < 6; i++) {
                response.forEach(element => {
                    
                    $('[data-week-no="' + i + '"] .day:nth-child(' + weekday[element.day] + ')')
                        .attr('disabled', false);
                    $('[data-week-no="' + i + '"] .day:nth-child(' + weekday[element.day] +
                        ') span').addClass('select');

                });

            }
        }
    });


}
$('.calendar-container').calendar({
    onClickMonthNext: function(date) {
        availableFunction();
    },
});


$('.calendar-container').calendar({
    onClickMonthPrev: function(date) {
        availableFunction();
    },
});


$('.calendar-container').calendar({
    onClickToday: function(date) {
        availableFunction();
    },
});

$('.calendar-container').calendar({
    onChangeMonth: function(date) {
        availableFunction();
    },
});



$('#appointment_time').one("mouseover", function() {
    var url = "{{ route('admin.check-availableDays') }}";
    $.easyAjax({
        type: 'GET',
        url: url,
        messagePosition: "toastr",
        success: function(response) {
            elementDay = response;
            var weekday = new Array(8);
            weekday["Sunday"] = 1;
            weekday["Monday"] = 2;
            weekday["Tuesday"] = 3;
            weekday["Wednesday"] = 4;
            weekday["Thursday"] = 5;
            weekday["Friday"] = 6;
            weekday["Saturday"] = 7;

            $('[data-week-no] .day').attr("disabled", "disabled");
            for (var i = 1; i < 6; i++) {
                response.forEach(element => {
                    console.log(weekday[element.day]);
                    $('[data-week-no="' + i + '"] .day:nth-child(' + weekday[element.day] +')')
                        .attr('disabled', false);
                    $('[data-week-no="' + i + '"] .day:nth-child(' + weekday[element.day] +
                        ') span').addClass('select');
                });
            }
        }
    });
})



$('.calendar-container').calendar({
    date: new Date() // today
});
$('.calendar-container').calendar({
    weekDayLength: 2
});

$('#button').on('click', '.time', function() {

    var url = "{{ route('admin.check-appointments') }}";
    $('#appointment_time').val($('#date').val() + ' ' + $(this).attr('id'));

    $.ajax({
        type: 'POST',
        url: url,
        data: {
            "_token": "{{ csrf_token() }}",
            'date': $('#date').val(),
            'time': $(this).attr('id'),

        },
        success: function(response) {

            $("#sales_member_id ").attr('disabled', false)
            $("#sales_member_id option").each(function() {
                $(this).remove();
            });
            $('.modal-content').click();
            if (response != null) {
                response.forEach(element => {

                    if (element != null) {
                        $('#sales_member_id').append("<option value=" + element.id + ">" +
                            element.first_name + ' ' + element.last_name + "</option>");

                    }
                });

            }

        },
        beforeSend: function() {
            $('.loader').show()
            $('body').css('opacity', 0.3)
        },
        complete: function() {
            $('.loader').hide();
            $('body').css('opacity', 1)
        }

    });
    return false;
});

$('.calendar-container').calendar({

    onClickDate: function(date) {
        availableFunction();
        $('.calendar-container').updateCalendarOptions({
            date: date
        });

        var date = new Date(date);
        $('#date').val(((date.getMonth() > 8) ? (date.getMonth() + 1) : (
                '0' + (date.getMonth() +
                    1))) +
            '-' + ((date
                .getDate() > 9) ? date.getDate() : ('0' + date.getDate())) + '-' + date
            .getFullYear());

        //available time

        var url = "{{ route('admin.check-time') }}";

        $.ajax({
            type: 'POST',
            url: url,
            data: {
                "_token": "{{ csrf_token() }}",
                'date': $('#date').val(),
            },
            success: function(response) {
                $("#button button").each(function() {
                    $(this).remove();
                });

                if (response) {
                    response.forEach(element => {

                        if (element != null) {
                            $('#button').append("<button type=" + 'button' +
                                " class=" +
                                'time' + " id=" +
                                element + ">" + element +
                                "</button>");

                        }
                    });
                } else {
                    $('#button').append(
                        "<button  type='button' class='demo'>No User Available </button>"
                    );
                }

            },
            beforeSend: function() {
                $('.loader').show()
                $('body').css('opacity', 0.3)
            },
            complete: function() {
                $('.loader').hide();
                $('body').css('opacity', 1)
            }
        });
    }

});




function check() {
    var url = "{{ route('admin.check-appointments') }}";
    $("#sales_member_id ").attr('disabled', true)

    // $('#sales_member_id').addClass('disabled');
    $.easyAjax({
        type: 'POST',
        url: url,
        file: true,
        container: "#appointment-edit-form",
        messagePosition: "toastr",
        success: function(response) {
            // return response;
            $("#sales_member_id ").attr('disabled', false)
            $("#sales_member_id option").each(function() {
                $(this).remove();
            });

            response.forEach(element => {

                if (element != null) {
                    $('#sales_member_id').append("<option value=" + element.id + ">" +
                        element
                        .first_name + ' ' + element.last_name + "</option>");

                }
            });

        }
    });
}
// $('.datetimepicker').daterangepicker({
//     locale: {
//         format: 'YYYY-MM-DD'
//     },
//     singleDatePicker: true,
//     timePicker: false,
// });
</script>